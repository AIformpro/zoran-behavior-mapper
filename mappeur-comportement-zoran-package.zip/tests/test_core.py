from mc_zoran.core import MappeurComportementZoran

def test_enregistrer():
    m = MappeurComportementZoran()
    m.enregistrer(1, "test")
    assert "test" in m.data["event"].values
