import pandas as pd
import matplotlib.pyplot as plt

class MappeurComportementZoran:
    def __init__(self):
        self.data = pd.DataFrame(columns=["time", "event"])
    def enregistrer(self, time, event):
        self.data.loc[len(self.data)] = [time, event]
    def analyser(self):
        return self.data["event"].value_counts().to_dict()
    def visualiser(self):
        self.data["event"].value_counts().plot(kind="bar")
        plt.show()
