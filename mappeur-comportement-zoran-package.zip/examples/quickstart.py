from mc_zoran.core import MappeurComportementZoran

m = MappeurComportementZoran()
m.enregistrer(1, "action1")
m.enregistrer(2, "action2")
print(m.analyser())
